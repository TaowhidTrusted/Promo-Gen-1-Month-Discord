
# UPDATE v1.3
- Fully Request Based
- Much Faster
- CF Bypass
- No errors
- Threading
- Hella Fast

# PREVIEW

- Main Page
<img width="371" alt="image" src="https://github.com/user-attachments/assets/adb1bc84-d7ab-4733-ab77-5f8fa481bbb2">

- Generating Promos
- <img width="651" alt="image" src="https://github.com/user-attachments/assets/882edb06-de89-4a30-b0ca-b2235ecdcb45">


# PROMO GEN V2
- This is V2 of my OG promo gen, this one makes requests to chess.com, collects UIDs then collects the promo
- This is all done within a few seconds generating hundreds of promos per second!

# USAGE
- Open `./data/proxies.txt` and put your proxies in either `user:pass@ip:port` or `ip:port`

# INFO
Scrapes a UUID off random users then uses it in the request

Fully **request based** meaning it is **VERY** fast 

Please star this, thank you!

just run `main.py` and it starts genning promos 

# CONTACT

join discord --> https://discord.gg/csolve

join tg --> https://t.me/csolver

Website --> https://csolver.xyz

dm me --> `csolver.py` on discord
